export class LocalStorage {
    
}
